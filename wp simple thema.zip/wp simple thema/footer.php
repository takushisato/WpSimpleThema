<footer>
    &copy; takushisato simple thema.
</footer>
<?php wp_footer(); ?>
</body>
</html>